import fs from "fs";
import path from "path";
import type { Metadata } from "next";
import { notFound } from "next/navigation";

import Affiliate from "@/components/cert/Affiliate";
import CareerInfo from "@/components/cert/CareerInfo";
import CertificateIntro from "@/components/cert/CertificateIntro";
import EligibilityInfo from "@/components/cert/EligibilityInfo";
import CertHero from "@/components/cert/CertHero";
import CertSummary from "@/components/cert/CertSummary";
import CostInfo from "@/components/cert/CostInfo";
import ExamStatistics from "@/components/cert/ExamStatistics";
import FAQ from "@/components/cert/FAQ";
import OfficialInfo from "@/components/cert/OfficialInfo";
import RealityGuide from "@/components/cert/RealityGuide";
import Related from "@/components/cert/Related";
import StudyStrategy from "@/components/cert/StudyStrategy";
import TrustInfo from "@/components/cert/TrustInfo";
import FinalCTA from "@/components/cert/FinalCTA";
import FadeInSection from "@/components/common/FadeInSection";

type CertData = {
  basic: {
    slug: string;
    name: string;
    shortName: string;
    type: "national" | "private";
    licenseType: string;
    category: string;
    agency: string;
  };

  hero: {
    title: string;
    subtitle: string;
    image?: string;
  };

  certificateIntro?: {
    title: string;
    description: string;
    highlights?: string[];
  };

  eligibility?: {
    title: string;
    status: "none" | "conditional" | "restricted";
    statusLabel: string;
    summary: string;
    conditions?: {
      label: string;
      description: string;
    }[];
    commonQuestion?: {
      question: string;
      answer: string;
    };
    officialNotice?: string;
  };

  display?: {
    charts?: boolean;
    career?: boolean;
    benefits?: boolean;
    cost?: boolean;
    schedule?: boolean;
    affiliate?: boolean;
  };

  keyInfo: {
    title: string;
    items: {
      label: string;
      value: string;
      note?: string;
    }[];
  };

  statistics?: {
    enabled?: boolean;
    title?: string;
    summary?: string;
    groups?: {
      id: string;
      title: string;
      description?: string;
      items: {
        year: number;
        applicants: number;
        passed: number;
        passRate: number;
      }[];
    }[];
    source?: {
      label?: string;
      url?: string;
      lastVerified?: string;
    };
    analysis?: string[];
    notice?: string;
  };

  realityGuide?: {
    title: string;
    summary: string;
    recommendedFor: string[];
    reconsiderIf: string[];
    beforeStart: string[];
    realityPoints: string[];
    firstStep?: {
      title: string;
      description: string;
    };
    nextStep?: {
      title: string;
      description: string;
    };
  };

  exam?: {
    written?: string;
    practical?: string;
    passingCriteria?: string;
    subjects?: string[];
  };

  charts?: {
    examWeight?: {
      enabled: boolean;
      items: {
        label: string;
        value: number;
      }[];
    };
  };

  cost?: {
    title: string;
    summary?: string;
    items: {
      label: string;
      value: string;
      note?: string;
    }[];
    realisticNote?: string;
  };

  studyStrategy?: string[];

  career?: {
    title: string;
    summary?: string;
    sections: {
      title: string;
      items: {
        label: string;
        description: string;
      }[];
    }[];
    realisticNote?: string;
  };

  officialInfo?: {
    title: string;
    summary?: string;
    organization: string;
    website: string;
    items: {
      label: string;
      description: string;
    }[];
    importantNotice?: string[];
    buttons?: {
      title: string;
      url: string;
    }[];
  };

  affiliate?: {
    lecture?: string;
    book?: string;
    application?: string;
  };

  faq?: {
    question: string;
    answer: string;
  }[];

  related?: string[];

  seo?: {
    title: string;
    description: string;
    keywords?: string[];
  };


  trustInfo?: {
    title: string;
    description?: string;
    sourceLabel: string;
    sourceUrl?: string;
    lastVerified?: string;
    lastUpdated?: string;
    notice?: string;
  };

  finalCta?: {
    title: string;
    description?: string;
    primaryButton?: {
      label: string;
      url: string;
    };
    secondaryButton?: {
      label: string;
      url: string;
    };
  };

  update?: {
    version: string;
    lastUpdated: string;
    lastVerified: string;
    verified: boolean;
    note?: string;
  };
};

type PageProps = {
  params: Promise<{
    slug: string;
  }>;
};

function getCertData(slug: string): CertData | null {
  const filePath = path.join(
    process.cwd(),
    "data",
    "certificates",
    `${slug}.json`
  );

  if (!fs.existsSync(filePath)) {
    return null;
  }

  try {
    const file = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(file) as CertData;
  } catch (error) {
    console.error(`자격증 JSON 읽기 실패: ${slug}`, error);
    return null;
  }
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const cert = getCertData(slug);

  if (!cert) {
    return {
      title: "자격증 정보를 찾을 수 없습니다",
    };
  }

  return {
    title: cert.seo?.title ?? cert.basic.name,
    description: cert.seo?.description ?? cert.hero.subtitle,
    keywords: cert.seo?.keywords,
  };
}

export default async function CertDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const cert = getCertData(slug);

  if (!cert) {
    notFound();
  }

  const showStatistics = cert.statistics?.enabled === true;


  const showCost =
    cert.display?.cost !== false &&
    Boolean(cert.cost);

  const showCareer =
    cert.display?.career !== false &&
    Boolean(cert.career);

  const showAffiliate =
    cert.display?.affiliate !== false &&
    Boolean(
      cert.affiliate?.lecture ||
        cert.affiliate?.book ||
        cert.affiliate?.application
    );

  const difficulty =
    cert.keyInfo.items.find((item) => item.label === "현실 난이도")?.value ??
    "정보 확인 중";

  const studyPeriod =
    cert.keyInfo.items.find((item) => item.label === "평균 준비기간")?.value ??
    "개인별 차이";

  const usefulness =
    cert.keyInfo.items.find((item) => item.label === "취업 활용도")?.value ??
    "정보 확인 중";

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <CertHero
        name={cert.hero.title}
        summary={cert.hero.subtitle}
        licenseType={cert.basic.licenseType}
        category={cert.basic.category}
        agency={cert.basic.agency}
        image={cert.hero.image}
        eligibility={cert.eligibility?.statusLabel ?? "확인 필요"}
        difficulty={difficulty}
        studyPeriod={studyPeriod}
        usefulness={usefulness}
      />

      <section className="mx-auto max-w-[1200px] px-5 py-10 md:px-6 md:py-14">
        <FadeInSection>
          <CertificateIntro data={cert.certificateIntro} />
        </FadeInSection>

        <FadeInSection delay={60} className="mt-10 md:mt-12">
          <OfficialInfo
            data={cert.officialInfo}
            exam={cert.exam}
            examWeight={cert.charts?.examWeight?.items}
          />
        </FadeInSection>


        {showStatistics && (
          <FadeInSection delay={100} className="mt-10 md:mt-12">
            <ExamStatistics statistics={cert.statistics} />
          </FadeInSection>
        )}

        <FadeInSection delay={140}>
          <EligibilityInfo data={cert.eligibility} />
        </FadeInSection>


        <FadeInSection delay={160} className="mt-10">
          <CertSummary
            title={cert.keyInfo.title}
            items={cert.keyInfo.items}
          />
        </FadeInSection>

        <FadeInSection delay={180}>
          <RealityGuide data={cert.realityGuide} />
        </FadeInSection>

        {showCost && (
          <FadeInSection delay={200}>
            <CostInfo data={cert.cost} />
          </FadeInSection>
        )}

        {cert.studyStrategy?.length ? (
          <FadeInSection delay={220}>
            <StudyStrategy items={cert.studyStrategy} />
          </FadeInSection>
        ) : null}

        {showCareer && (
          <FadeInSection delay={240}>
            <CareerInfo data={cert.career} />
          </FadeInSection>
        )}

        {showAffiliate && (
          <FadeInSection delay={260}>
            <Affiliate affiliate={cert.affiliate} />
          </FadeInSection>
        )}

        {cert.faq?.length ? (
          <FadeInSection delay={280}>
            <FAQ items={cert.faq} />
          </FadeInSection>
        ) : null}

        {cert.trustInfo ? (
          <FadeInSection delay={290}>
            <TrustInfo data={cert.trustInfo} />
          </FadeInSection>
        ) : null}

        {cert.finalCta ? (
          <FadeInSection delay={295}>
            <FinalCTA data={cert.finalCta} />
          </FadeInSection>
        ) : null}

        {cert.related?.length ? (
          <FadeInSection delay={300}>
            <Related items={cert.related} />
          </FadeInSection>
        ) : null}
      </section>
    </main>
  );
}
